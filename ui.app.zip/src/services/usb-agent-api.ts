import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface PrintResponse {
  ok: boolean;
  // from your .NET response:
  resultPtr?: number;
  lastWin32Error?: number;

  // optional error fields if you return ProblemDetails etc.
  error?: string;
  message?: string;
  detail?: string;

  dllArgs?: {
    dataLen: number;
    vid: string;
    pid: string;
    serialList: string;
    matchSerial: string;
  };

  device?: UsbDeviceInfo;
}

export interface UsbDeviceInfo {
  name: string;
  pnpDeviceId: string;
  vid: string | null;
  pid: string | null;
  serial: string | null;
  status: string | null;
}

export interface DevicesResponse {
  count: number;
  devices: UsbDeviceInfo[];
}

export interface StoredBinding {
  machineId: string;
  vid: string;
  pid: string;
  serial: string;
  friendlyName: string;
  boundAt: string;
}

@Injectable({
  providedIn: 'root',
})
export class UsbAgentApi {
  constructor(private http: HttpClient) {}

  getDevices(): Observable<DevicesResponse> {
    return this.http.get<DevicesResponse>('/api/usb/devices');
  }

  getBinding(): Observable<{ ok: boolean; binding: StoredBinding | null }> {
    return this.http.get<{ ok: boolean; binding: StoredBinding | null }>('/api/printer/identity');
  }

  bindPrinter(payload: { vid: string; pid: string; serial?: string; friendlyName?: string }) {
    return this.http.post<{ ok: boolean; binding: StoredBinding }>('/api/printer/bind', payload);
  }

print(payload: { vid: string; pid: string; serial?: string; dataBase64: string }) {
  return this.http.post<PrintResponse>('/api/printer/print', payload);
}

}
