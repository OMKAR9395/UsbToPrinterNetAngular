import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';

import { StoredBinding, UsbAgentApi, UsbDeviceInfo } from '../../services/usb-agent-api';

@Component({
  selector: 'app-printer-panel',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,

    MatSnackBarModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatButtonModule,
  ],
  templateUrl: './printer-panel.html',
  styleUrl: './printer-panel.scss',
})
export class PrinterPanel implements OnInit {
  loading = false;

  private pending = 0;

  devices: UsbDeviceInfo[] = [];
  selected: UsbDeviceInfo | null = null;

  binding: StoredBinding | null = null;

  displayedColumns = ['select', 'name', 'vidpid', 'serial', 'status'];

  form = new FormGroup({
    tspl: new FormControl<string>(
      `SIZE 50 mm,50 mm
GAP 0 mm,0 mm
DIRECTION 1
SPEED 2
DENSITY 15
CODEPAGE 850
CLS
TEXT 20,20,"3",0,3,3,"HELLO TSC"
BAR 20,120,500,6
TEXT 20,160,"3",0,2,2,"VID 1203 PID 0230"
PRINT 1,1
`,
      { nonNullable: true, validators: [Validators.required, Validators.minLength(10)] }
    ),
  });

  constructor(private api: UsbAgentApi, private snack: MatSnackBar) {}

  ngOnInit(): void {
    this.refreshAll();
  }

  refreshAll() {
    this.loadDevices();
    this.loadBinding();
  }

  isBindable(d: UsbDeviceInfo | null): boolean {
    if (!d) return false;
    return !!(d.vid && d.pid);
  }

  pick(d: UsbDeviceInfo) {
    this.selected = d;
  }

  loadDevices() {
    this.withLoader(
      () => this.api.getDevices(),
      (res) => {
        this.devices = res.devices || [];

        if (this.selected) {
          const still = this.devices.find((x) => x.pnpDeviceId === this.selected!.pnpDeviceId);
          this.selected = still || null;
        }

        this.toast(`Devices loaded: ${res.count}`, 'ok');
      },
      true
    );
  }

  loadBinding() {
    this.withLoader(
      () => this.api.getBinding(),
      (res) => {
        this.binding = res.binding ?? null;
      },
      false
    );
  }

  bindSelected() {
    if (!this.selected) {
      this.toast('Select a USB device first', 'warn');
      return;
    }
    if (!this.isBindable(this.selected)) {
      this.toast('Selected device has no VID/PID (not bindable)', 'warn');
      return;
    }

    const payload = {
      vid: this.selected.vid!,
      pid: this.selected.pid!,
      serial: this.selected.serial || '',
      friendlyName: this.selected.name || 'USB Device',
    };

    this.withLoader(
      () => this.api.bindPrinter(payload),
      (res) => {
        this.binding = res.binding;
        this.toast('Bind successful', 'ok');
      },
      false
    );
  }

  print() {
    if (!this.binding) {
      this.toast('Printer not bound. Bind first.', 'warn');
      return;
    }
    if (this.form.invalid) {
      this.toast('TSPL is empty/invalid', 'warn');
      return;
    }

    const tspl = this.normalizeTspl(this.form.controls.tspl.value);
    const base64 = this.toBase64Ascii(tspl);

    const payload = {
      vid: this.binding.vid,
      pid: this.binding.pid,
      serial: this.binding.serial,
      dataBase64: base64,
    };

    this.withLoader(
      () => this.api.print(payload),
      (res) => {
        if (res.ok) {
          this.toast(`Print OK (ptr=${res.resultPtr ?? 'n/a'})`, 'ok');
        } else {
          const msg =
            res.message ||
            res.error ||
            res.detail ||
            `Print failed (ptr=${res.resultPtr ?? 0}, winErr=${res.lastWin32Error ?? 0})`;
          this.toast(msg, 'err');
        }
      },
      false
    );
  }

  // ---------- helpers ----------

  private normalizeTspl(s: string): string {
    let t = (s || '').replace(/\r\n/g, '\n').replace(/\n/g, '\r\n');
    if (!t.endsWith('\r\n')) t += '\r\n';
    return t;
  }

  private toBase64Ascii(text: string): string {
    const bytes = new TextEncoder().encode(text);
    let bin = '';
    bytes.forEach((b) => (bin += String.fromCharCode(b)));
    return btoa(bin);
  }

  private startLoad() {
    this.pending++;
    this.loading = this.pending > 0;
  }

  private endLoad() {
    this.pending = Math.max(0, this.pending - 1);
    this.loading = this.pending > 0;
  }

  private withLoader<T>(
    call: () => Observable<T>,
    onOk: (res: T) => void,
    showSuccessToast = false
  ) {
    this.startLoad();

    call()
      .pipe(finalize(() => this.endLoad()))
      .subscribe({
        next: (res) => {
          onOk(res);
          // showSuccessToast reserved (जर तुला generic toast हवा असेल तर)
          if (showSuccessToast) {
            // noop by default; specific calls already show toast
          }
        },
        error: (err) => {
          this.endLoad(); // safety
          this.toast(this.extractError(err), 'err');
        },
      });
  }

  private extractError(err: any): string {
    const problem = err?.error;
    if (typeof problem === 'string') return problem;
    if (problem?.message) return problem.message;
    if (problem?.error) return problem.error;
    if (problem?.detail) return problem.detail;
    if (err?.message) return err.message;
    return 'Request failed';
  }

  private toast(message: string, type: 'ok' | 'warn' | 'err') {
    this.snack.open(message, 'Close', {
      duration: type === 'ok' ? 2500 : 4000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: [`toast-${type}`],
    });
  }
}
