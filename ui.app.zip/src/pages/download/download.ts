import { Component } from '@angular/core';

@Component({
  selector: 'app-download',
  imports: [],
  templateUrl: './download.html',
  styleUrl: './download.scss',
})
export class Download {

}
