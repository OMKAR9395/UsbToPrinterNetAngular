import {
  MatFormFieldModule
} from "./chunk-2B3ENYEM.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-D25O6EPU.js";
import "./chunk-Z3XFY25S.js";
import "./chunk-NIFXDJIO.js";
import "./chunk-NWZSMDRH.js";
import "./chunk-42QFQP6S.js";
import "./chunk-N4DOILP3.js";
import "./chunk-X4TSTDK5.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-6AVURISY.js";
import "./chunk-356U2M5Y.js";
import "./chunk-MTFW23KV.js";
import "./chunk-MFGXPCU3.js";
import "./chunk-FTXEKBYQ.js";
import "./chunk-44ZJMWPF.js";
import "./chunk-OGUMFMAP.js";
import "./chunk-RIOTEP5Z.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
